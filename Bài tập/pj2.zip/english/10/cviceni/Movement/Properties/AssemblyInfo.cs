﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Obecné informace o sestavení jsou řízeny přes následující 
// sadu atributů. Změnou hodnot těchto atributů se upraví informace
// přidružené k sestavení.
[assembly: AssemblyTitle("Movement")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("katedra informatiky")]
[assembly: AssemblyProduct("Movement")]
[assembly: AssemblyCopyright("Copyright © katedra informatiky 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Nastavení atributu ComVisible na hodnotu False udělá typy v tomto sestavení neviditelné 
// pro komponenty modelu COM.  Jestliže potřebujete přistupovat k typům v tomto sestavení z 
// modelu COM, nastavte atribut ComVisible daného typu na hodnotu True.
[assembly: ComVisible(false)]

// Následující identifikátor GUID slouží k identifikaci knihovny typů, jestliže je projekt vystaven objektům modelu COM
[assembly: Guid("440a2359-369b-4377-ba48-07110f04ea6f")]

// Informace o verzi sestavení se skládá z následujících čtyř hodnot:
//
//      Hlavní verze
//      Podverze 
//      Číslo sestavení
//      Revize
//
// Lze zadat všechny hodnoty nebo nechat hodnoty Čísel Sestavení a Revize ve výchozím nastavení 
// použitím '*' jak je ukázáno dále:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
